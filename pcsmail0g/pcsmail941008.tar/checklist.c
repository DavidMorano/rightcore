static char sccsid[] = "@(#)checklist.c	PCS 3.0";

/************************************************************************
 *									
 * The information contained herein is for the use of AT&T Information	
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	
 *									
 *	(c) 1984 AT&T Information Systems				
 *									
 * Authors of the contents of this file:				
 *									
 *		J.Mukerji						


  checkreclist() checks for validity of all the currently specified
  recipients of the mail message.


************************************************************************/



#include	<string.h>

#include	<stdio.h>

#include	"config.h"

#include	"smail.h"



/* external variables */

extern struct global	g ;



#define firstname()	realname = strtok( s, "," );\
	        *selectname = '\0'; *curaddr = '\0';\
	        first = 1

#define nextname()	if(!first){ *npt++ = ','; *npt++ = ' ';}\
	        else first = 0;\
	        {\
	            register char *d1,*d2;\
	            d1 = selectname; d2 = curaddr;\
	            for( ; *npt++ = *d1++; );\
	            npt--;\
	            if( *d2 != '\0' )\
	            {\
	                *npt++ = ' ';\
	                *npt++ = '<';\
	                for( ; *npt++ = *d2++; );\
	                npt--;\
	                *npt++ = '>';\
	            }\
	        }\
	        *selectname = '\0'; *curaddr = '\0';\
	        realname = strtok( 0, ",");


#define endlist()	*npt = '\0'

#define beginlist(name)	npt = s1; str = name


checkreclist(mode)
int mode;
{
	register char *realname;
	int state;
	char *str;
	char first;
	char *npt;


	state = error = 0;
	ambiguous = 0;		/* be optimistic */
	if (tonames <= 0)
	    printf("\nWARNING: There are no primary recipients.\n");

/* check recipient list */

	if (tonames > 0 || ccnames > 0 || bccnames > 0)

	    while( state < 3 ) {

	        switch(state) {

	        case 0:
	            strcpy(s,recipient);

	            beginlist(recipient);

	            state++;
	            break;

	        case 1:
	            state++;
	            if(*copyto == '\0') continue;

	            strcpy(s,copyto);

	            beginlist(copyto);

	            break;

	        case 2:
	            state++;
	            if(*bcopyto == '\0') continue;

	            strcpy(s,bcopyto);

	            beginlist(bcopyto);

	            break;

	        default:
	            printf("checkreclist: This should not happen!\n");
	            rmtemp(0);

	        }

/* The first word is always a name in state 1*/

	        firstname();

	        if (ex_mode == ORIG) {

/* If the first name cannot be mapped to a valid address
		 * and a return path has been provided, then try to use
		 * the return path instead
		 */

	            if (isret && (realname != NULL) && (mode == 0)
	                && (*realname != NULL)	/*PAS-JM 2/8/85*/
	                && f_interactive && (state == 1)
	                && (strchr(realname,'<') == NULL)) {

	                error = 0;	/* JM 2/22/85 */

	                if (checkname(realname,mode) != 1) {

/* "\nWill try to use the return address from the mail envelope.\n\n"); */

	                    if (checkname(retpath,mode) == 1) {

	                        strcpy(selectname, realname);

#ifdef	COMMENT
	                        printf(
	                            "The address being used for %s is %s\n",
	                            selectname,curaddr);
#endif

	                    } else {

/* "The return address on the envelope doesn't make any sense either!\n"); */

	                        error = 1;
	                    }
	                }
	                nextname();

	            }

/*PAS-JM 2/8/85*/

	            while (realname != NULL && *realname != NULL) {

	                if (checkname(realname,mode) != 1) {

	                    error = 1;
	                }
	                nextname();

	            }
	        }

	        endlist();

	        if (strlen(s1) >= BUFSIZE) {

	            s1[BUFSIZE-1] = '\0';
	            *strrchr(s1, ',') = '\0';

	            printf(
	                "%s: warning - too many recipients, list truncated\n",
	                g.progname);

	        }
	        strcpy( str, s1 );

	    }

/* setup the name lists properly */

	if (ambiguous) {

	    tonames = getnames(recipient);

	    ccnames = getnames(copyto);

	    bccnames= getnames(bcopyto);

	}
	*realto = '\0';

}


