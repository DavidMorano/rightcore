static char sccsid[] = "@(#)checkname.c	PCS 3.0" ;


#define	DEBUG_CHECKNAME	0


/************************************************************************
 *									
 * The information contained herein is for the use of AT&T Information	
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	
 *									
 *	(c) 1984 AT&T Information Systems				
 *									
 * Authors of the contents of this file:				
 *									
 *		J.Mukerji						
 *									
*									
*	FUNCTIONAL DESCRIPTION:						
*	'Checkname' checks all entries in the table for mailing.	
*									
*	PARAMETERS:							
*	mailaddress -	a string containing a name			
*	flag	 -	an integer specifying the mode in which 	
*			checkname is called.				
*									
*	RETURNED VALUE:							
*									
*	SUBROUTINES CALLED:						
*									
*	parsename,	checkname					
*									
*	GLOBAL VARIABLES USED:						
*									
*	selectname,	curaddr						
*									
*	CAUTION!!! THIS CODE IS MORE COMPLICATED THAN YOU THINK IT IS!	
*	Lists are processed recursively while some info about them is	
*	saved as side effect in global variable. You MUST BE CAREFUL	
*	about restoring the value of global variables before exiting	
*	a recursive invocation OR ELSE ****				
*									

***********************************************************************/



#include	<string.h>
#include	<pwd.h>
#include	<stdio.h>

#include	"config.h"
#include	"smail.h"
#include	"misc.h"



/* external subroutines */

extern char	*parsename() ;


/* local subroutines */

static		checknet() ;
static		disambiguate() ;
static int	add_to_translation() ;

char		*namefromgecos() ;


/* local data */

static struct table	*foundnames[500] ;	/* list of ambiguous names */
static struct table	**foundpt ;



/* check names for validity */

int checkname(mailaddress,flag)
char	*mailaddress ;
int	flag ;
{
	FILE *fopen(), *fp ;

	struct table *aname ;

	int i,j,k,mark ;
	int ngroup ;
	int oflag ;
	int	type ;
	int	f_once ;
	int	f_first ;

	char group[BUFSIZE];		/*JM030185*/
	char s[BUFSIZE] ;
	char ss[BUFSIZE] ;
	char lastname[40] ;
	char	*cp, *cp2 ;


	mailaddress = parsename(mailaddress) ;

	strcpy(ss, selectname) ;

	strcat(ss,":") ;

	if ( *curaddr != '\0' ) {

	    if ((*selectname != ALIAS) &&
	        (*selectname != STANLIST) &&
	        (*selectname != ALTLIST)) {

	        checknet(selectname, curaddr, &mark, &oflag, &flag, ss) ;

	    } else fprintf(stdout,"%-15s%s\t%s\n", 
	        selectname, curaddr,
	        "list or alias can't have associated address") ;

	    return mark ;
	}

	oflag = 0 ;

/* check for groupname */

	if ((*mailaddress == STANLIST) || (*mailaddress == ALTLIST)) {

	    mailaddress++ ;

/* open mailing list */

/*JM030185*/
	    if ((ngroup = genname(mailaddress,group,sizeof(group))) == 0) {

	        if (flag == 1) fprintf(stdout,
	            "%-15s (** unknown mailing list **)\n",ss) ;

	        else if (flag == 2) fprintf(stdout,
	            "%-15s~%s (** unknown mailing list **)\n",
	            "",mailaddress) ;

	        else if(flag == 0) fprintf(stdout,
	            "warning: '%s' is an unknown mailing list\n",
	            mailaddress) ;

	        return -1 ;

	    } else if (ngroup > 1) {

	        if (flag == 1) fprintf(stdout,
	            "%-15sambiguous mailing list matches the following lists:\n%15s(",
	            ss,"") ;

	        else if (flag == 2) fprintf(stdout,
	            "%-15s~%s (ambiguous mailing list matching the following lists)\n%15s(",
	            "",mailaddress,"") ;

	        else if (flag == 0) fprintf(stdout,
	            "warning: '%s' is an ambiguous mailing list\n",
	            mailaddress) ;

	        if ((flag == 1) || (flag == 2)) {

	            i = 0 ;
	            while (group[i] != '\0') {

	                if (group[i] == ':')
	                    fprintf(stdout,")\n%15s(","") ;

	                else putc(group[i],stdout) ;

	                i++ ;
	            }
	            fprintf(stdout,")\n") ;
	        }
	        return -1 ;
	    }

	    if ((fp = fopen(group,"r")) == NULL) {

	        fprintf(stdout,
	            "warning: '%s' cannnot be read\n",group) ;

	        return -1 ;
	    }

	    if (flag == 1) fprintf(stdout,
	        "%-15smailing list (%s)\n",ss,group) ;

	    else if (flag == 2) fprintf(stdout,
	        "%-15s~%s mailing list (%s)\n",
	        "",mailaddress,group) ;

#if	DEBUG_CHECKNAME
	    eprintf("i'm here 1\n") ;
#endif

	    if (flag == -1) fprintf(stdout,"%s\n",group) ;

/* read the group file */

	    f_first = FALSE ;
	    if (flag > 0) while (fgetline(fp,s,BUFSIZE) > 0) {

/* skip over leading white space */

	        cp = s ;
	        while ((*cp == ' ') || (*cp == '\t')) cp += 1 ;

/* ignore comment lines */

	        if (*cp == '#') continue ;

/* read up to some more white space or the end */

	        if ((cp2 = strpbrk(cp," \t\\\n")) != ((char *) 0))
	            *cp2 = '\0' ;

/* is it a UPAS first line ? */

	        if (! f_first) {

	            f_first = TRUE ;
	            if (strcmp(cp,mailaddress) == 0) continue ;

	        }

	        if (*cp == '\0') continue ;

	        checkname(cp,2) ;

	    }

	    fclose (fp) ;

#if	DEBUG_CHECKNAME
	    eprintf("i'm here 2\n") ;
#endif

/* restore state of global variables after recursive call */

	    strcpy(selectname, --mailaddress) ;
	    *curaddr = '\0' ;

	    return(1) ;
	}

#if	DEBUG_CHECKNAME
	eprintf("i'm here 3\n") ;
#endif

/* translate name if can */
normal:
	mark = 0 ;
	foundpt = foundnames ;
	if (strpbrk(mailaddress,"!@/:%") == NULL) {

#if	DEBUG_CHECKNAME
	    eprintf("i'm here 3a\n") ;
#endif

	    f_once = FALSE ;
	    while (! f_once) {

	        f_once = TRUE ;

/* look in the user's local name translation database */

#if	DEBUG_CHECKNAME
	        eprintf("checking user's translations\n") ;
#endif

	        type = TT_USER ;
		i = 0 ;
	        while (TRUE) {

#if	DEBUG_CHECKNAME
	            eprintf("i'm here 3b\n") ;
#endif

	            j = findname(mailaddress,&i,type) ;

	            if (j < 0) break ;

	            aname = name[i] ;
	            if (aname->user[0] == ALIAS) k = 1 ;

	            else k = 0 ;

/* expand to network address for all addresses, even aliases.  PAS 2/15/85 */

/* Save the alias for later use	PAS 2/25/85 */

/*		if ( k == 0 ) mark++;*/

#if	DEBUG_CHECKNAME
	            eprintf("i'm here 3c\n") ;
#endif

	            mark++; 	/* set mark even if alias PAS-JM 2/12/85 */
	            sprintf(lastname,"(%s)",&aname->user[k]) ;

#if	DEBUG_CHECKNAME
	            eprintf("i'm here 3d\n") ;
#endif

	            if (strncmp( aname->user, "NO", 2 ) == 0 ) {

	                fprintf(stdout,"%-15s	(unknown address)\n",
	                    aname->last) ;

	                error++ ;

	            } else if (flag == 1) {

	                fprintf(stdout,"%-15s%-20s%-30s\n",
	                    ss,aname->last,lastname) ;

	                *ss = '\0' ;

	            } else if (flag > 0) {

	                fprintf(stdout,"%-15s%-20s%-30s",
	                    "",aname->last,lastname) ;

	                fprintf(stdout,"\n") ;

	            } else if (flag == -1)
	                fprintf(stdout,"%s\n",aname->last) ;

	            if (mark < 20) *foundpt++ = aname ;

	            if (j == 0) break ;

	            i += 1 ;

	        } /* end while */

	        if (mark != 0) break ;

/* check for a local username FIRST !! */

#if	DEBUG_CHECKNAME
	        eprintf("checking \'%s\" for a user name\n",
			mailaddress) ;
#endif

	        if ((mark = lookup_passwd(mailaddress,flag)) != 0) break ;

/* convert any "all initials" (format 'd.a.m.') name into the old format */

	        cp = mailaddress ;
	        if ((cp[1] == '.') && (cp[3] == '.')) {

	            if (cp[4] == '\0') {

	                cp[1] = cp[2] ;
	                cp[2] = '\0' ;

	            } else if ((cp[5] == '.') && (cp[6] == '\0')) {

	                cp[1] = cp[2] ;
	                cp[2] = cp[4] ;
	                cp[3] = '\0' ;

	            }
	        }

/* look in the system-wide name translation database */

#if	DEBUG_CHECKNAME
	        eprintf("checking \"%s\" for a system name\n",
			mailaddress) ;
#endif

	        type = TT_SYSTEM ;
		i = 0 ;
	        while (1) {

#if	DEBUG_CHECKNAME
	            eprintf("i'm here 3b\n") ;
#endif

	            j = findname(mailaddress,&i,type) ;

	            if (j < 0) break ;

#if	DEBUG_CHECKNAME
	            eprintf("found a match\n") ;
#endif

	            aname = name[i] ;
	            if (aname->user[0] == ALIAS) k = 1 ;

	            else k = 0 ;

/* expand to network address for all addresses, even aliases.  PAS 2/15/85 */

/* Save the alias for later use	PAS 2/25/85 */

/*		if ( k == 0 ) mark++;*/

#if	DEBUG_CHECKNAME
	            eprintf("i'm here 3c\n") ;
#endif

	            mark++; 	/* set mark even if alias PAS-JM 2/12/85 */
	            sprintf(lastname,"(%s)",&aname->user[k]) ;

#if	DEBUG_CHECKNAME
	            eprintf("i'm here 3d\n") ;
#endif

	            if (strncmp( aname->user, "NO", 2 ) == 0 ) {

	                fprintf(stdout,"%-15s	(unknown address)\n",
	                    aname->last) ;

	                error++ ;

	            } else if (flag == 1) {

	                fprintf(stdout,"%-15s%-20s%-30s\n",
	                    ss,aname->last,lastname) ;

	                *ss = '\0' ;

	            } else if (flag > 0) {

	                fprintf(stdout,"%-15s%-20s%-30s",
	                    "",aname->last,lastname) ;

	                fprintf(stdout,"\n") ;

	            } else if (flag == -1)
	                fprintf(stdout,"%s\n",aname->last) ;

	            if (mark < 20) *foundpt++ = aname ;

	            if (j == 0) break ;

	            i += 1 ;

	        } /* end while */

	        if (mark != 0) break ;

#if	DEBUG_CHECKNAME
	        eprintf("checking for a user name again\n") ;
#endif

	        mark = lookup_passwd(mailaddress,flag) ;

	    } /* end while */

#if	DEBUG_CHECKNAME
	    eprintf("i'm here 3ea\n") ;
#endif

	} /* end if (bare name lookup) */

#if	DEBUG_CHECKNAME
	eprintf("i'm here 3eb\n") ;
#endif

	if (mark == 0) {

#if	DEBUG_CHECKNAME
	    eprintf("i'm here 4\n") ;
#endif

	    checknet( "", mailaddress, &mark, &oflag, &flag, ss) ;

	}

#if	DEBUG_CHECKNAME
	eprintf("i'm here 4a\n") ;
#endif

	if (mark == 0 && flag == 1 && oflag == 0)
	    fprintf(stdout,"%-15sunknown name\n",ss) ;

	else if (mark == 0 && flag == 2) fprintf(stdout,
	    "%-15s%-20s%-30s\n",
	    "",mailaddress,"(** unknown name **)") ;

	else if (mark == 0 && flag == 0) fprintf(stdout,
	    "warning: '%s' is an unknown name\n",mailaddress) ;

#if	DEBUG_CHECKNAME
	eprintf("i'm here 5\n") ;
#endif

	if ((flag == 0) && (mark > 1) && f_interactive) {

	    fprintf(stdout,
	        "\nwarning: '%s' is an ambiguous name\n",mailaddress) ;

	    disambiguate(&mark) ;

	}

	return mark ;
}
/* end subroutine (checkname) */


/* 
 * checknet() checks the validity of an absolute address and passes judgement
 * on it through the parameters mark, flag and oflag
 *
 * This is where code should be added to tie in any feedback from any delivery
 * system.
*/

static checknet( name, addr, mark, oflag, flag, ss )
char *name, *addr, *ss ;
int *mark, *oflag, *flag ;
{
	char	*netaddr ;
	char lastname[SYSLEN] ;
	char locaddr[SYSLEN] ;
	char *mailaddressj = NULL ;


	*mark = 1 ;
	if (strpbrk( addr, "@:!./%" ) == NULL ) {

/* this is probably a local login name try it as such */

	    if ((mailaddressj = namefromgecos(addr)) == NULL)
	        netaddr = "NOUSER" ;

	    else {
	        sprintf(locaddr, "!%s", addr) ;

	        netaddr = locaddr ;
	        ss = mailaddressj ;
	    }

	} else {
/* Here is where tie in with the delivery system for
	    address verification should go */

	    netaddr = addr ;
	}

	sprintf(lastname,"(%s)",netaddr) ;

	if (!strcmp(netaddr,"NOMAIL")) {

	    if (*flag == 1)
	        fprintf(stdout,"%-15s%-20s\n",
	            ss," unknown address") ;

	    *mark = 0 ;
	    *oflag = 1 ;

	} else if (!strcmp(netaddr,"NOUSER")) {

	    if (*flag == 1) fprintf(stdout,"%-15s%-20s\n",
	        ss," unknown user") ;

	    *mark = 0 ;
	    *oflag = 1 ;

	} else if (!strcmp(netaddr,"NODOM")) {

	    if (*flag == 1) fprintf(stdout,"%-15s%-20s\n",
	        ss," unknown domain and address") ;

	    *mark = 0 ;
	    *oflag = 1 ;

	} else if ( *flag == 1 ) fprintf(stdout,"%-15s%-20s%-30s\n",
	    ss,name,lastname) ;

	else if ( *flag > 0 ) {

	    fprintf(stdout,"%-15s%-20s%-30s",
	        "", addr , lastname) ;

	    fprintf(stdout,"\n") ;

	}

	if (*mark && *curaddr != '\0') {

	    strcpy( curaddr, netaddr ) ;

	    *realto = '\0' ;
	    ambiguous = 1 ;
	}
}
/* end subroutine (checknet) */


/*
 * disambiguate() is an integral part of checkname. It should not be moved 
 * out of this file. disambiguate first prints out a list of names that 
 * matched the given name and then asks the user to choose one. It then 
 * returns the chosen name to the user in the global variable mailaddress
 * it also returns 1 if a name is selcted and 0 if none is selcted in
 * the paramater *mark
*/

static disambiguate(mark)
int *mark ;
{
	struct table **iptr ;

	int  i, choice, k;	/* New variable k for handling aliases.
				 * This function wasn't being called when
				 * ambiguous name included an alias. The
				 * ambiguity wasn't even being flagged.
				 * Now that it is being flagged, it must be
				 * handled here. - PAS-JM 2/12/85
									 */
	char answer[20] ;


	printf("it matched the following names:\n\n") ;

again:
	iptr = foundnames ;
	i = 1 ;
	while (iptr < foundpt) {

	    k = 0;					/* PAS-JM 2/12/85 */
	    if ((*iptr)->user[0] == ALIAS) k = 1;	/* PAS-JM 2/12/85 */

	    printf("%2d\t%15s\t%15s\n", i, 
	        (*iptr)->last, (*iptr)->user+k);/* PAS-JM 2/12/85 */

	    iptr++ ;
	    i++ ;
	}

getans:
	printf("\nPlease select one (? for help, ") ;

	for ( i=1; i <= *mark; i++) printf("%2d, ", i) ;

	printf(" none) [none]: ") ;

	fgets(answer,20,stdin) ;

	if ((*answer == '\0' ) || (*answer == 'n')) {

/* none selected so return "" in selectname */

	    printf("\nNone selected\n") ;

	    strcpy( selectname, "  " ) ;

	    *curaddr = '\0' ;
	    *mark = 0 ;
	    ambiguous = 1 ;
	    return ;
	}

	if ((*answer == '?' ) || (sscanf(answer,"%d",&choice) == 0)) {

	    help(6) ;
	    printf("\n") ;
	    goto again ;

	}

	if ((choice > *mark) || (choice < 1)) {

	    printf("%d is out of range\n",choice) ;

	    goto getans ;
	}
	choice-- ;
	k = 0;						/* PAS-JM 2/12/85 */
	if (foundnames[choice]->user[0] == ALIAS) k = 1; /* PAS-JM 2/12/85 */

	printf("\nThe name you selected is: %s <%s>\n",
	    foundnames[choice]->last, foundnames[choice]->user+k) ;

/* PAS-JM 2/12/85 */

	printf("is that the one you wanted ? (yes, no) [yes] : ") ;

	fgets(answer, 20, stdin) ;

	if ( *answer == 'n' ) goto again ;

	if ( strncmp( foundnames[choice]->user+k, "NO", 2 ) == 0 ) {

	    printf(
	        "\nthe name that you have chosen has an unknown address") ;

	    printf(
	        "\nplease make another selection\n") ;

	    goto again ;
	}
	strcpy(selectname, foundnames[choice]->last) ;

	strcpy(curaddr, foundnames[choice]->user+k);	/* PAS-JM 2/12/85 */

	error = 0;					/* JM 2/22/85 */
	ambiguous = *mark = 1 ;
}
/* end subroutine (disambiguate) */


int lookup_passwd(name,flag)
char *name ;
int flag ;
{
	int	nmatch = 0 ;

	char	*username ;


#if	DEBUG_CHECKNAME
	eprintf("you are here in 'lookup_passwd' 1\n") ;
#endif

	username = namefromgecos(name) ;

#if	DEBUG_CHECKNAME
	eprintf("you are here in 'lookup_passwd' 2\n") ;
#endif

	if (username == NULL) return nmatch ;

#if	DEBUG_CHECKNAME
	eprintf("you are here in 'lookup_passwd' 3\n") ;
#endif

	nmatch += add_to_translation(username, name, flag) ;

#if	DEBUG_CHECKNAME
	eprintf("you are here in 'lookup_passwd' 4\n") ;
#endif

	return nmatch ;
}
/* end subroutine (lookup_passwd) */


char *namefromgecos(login)
char *login ;
{
	char	fixedname[BUFSIZE] ;


#ifndef	COMMENT
	struct passwd	*getpwnam(), *pwent ;

	int i ;

	char *c, *d, *t ;


	for (i = 0; i < 30; i++)
	    fixedname[i] = '\0' ;

	pwent = getpwnam(login) ;

	if (pwent == NULL) return NULL ;

	c = pwent->pw_gecos ;
	d = fixedname ;
	if ((t = strchr(c,'-')) != NULL) {

	    c = ++t ;
	    if ((t = strchr(c, '(')) != NULL) *t = '\0' ;

	}

	while (*c != '\0') *d++ = *c++ ;
#else
	fixedname[0] = '\0' ;
	gecosname(login,fixedname,BUFSIZE) ;
#endif

	return fixedname ;
}
/* end subroutine (namefromgecos) */


static int add_to_translation( last, user, flag )
char *last, *user ;
int flag ;
{
	struct table *nmalloc() ;
	struct table *tname ;

	char	locadr[300] ;


/* check for no space left in translation table */

	if ((tname = nmalloc()) == NULL) return 0 ;

/*
	save the name in the entry and put a pointer
	to the entry in the 'foundnames' list ;
	skip over the name that went in as input 
*/

	strcpy( tname->last, last ) ;

	strcpy( tname->user, user) ;

	sprintf( locadr, "(%s)", user ) ;

	if (flag == 1) {

	    fprintf(stdout,"%-15s%-20s%-30s[LOCAL]\n",
	        last,tname->last,locadr) ;

	} else if (flag > 0) fprintf(stdout,"%-15s%-20s%-30s%s\n",
	    "",tname->last,locadr,verbose?"[LOCAL]":"") ;

	else if (flag == -1) fprintf(stdout,"%s\n",tname->last) ;

	strcpy( selectname, tname->last ) ;

	strcpy( curaddr, tname->user ) ;

	ambiguous = 1 ;
	return 1 ;
}
/* end subroutine (add_to_translation) */


