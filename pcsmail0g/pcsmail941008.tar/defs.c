/* defs */


#include	<stdio.h>

#include	"config.h"
#include	"smail.h"



struct global	g ;



