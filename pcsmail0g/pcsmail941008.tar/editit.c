static char sccsid[] = "@(#)editit.c	PCS 3.0" ;

/************************************************************************
 *									*
 * The information contained herein is for the use of AT&T Information	*
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	*
 *									*
 *	(c) 1984 AT&T Information Systems				*
 *									*
 * Authors of the contents of this file:				*
 *									*
 *		J.Mukerji						*
 *									*


 * editit() does the necessary footwork for the edit command


*************************************************************************/



#include	<string.h>
#include	<stdio.h>

#include	"config.h"
#include	"header.h"
#include	"smail.h"



extern char table_has_changed() ;


/*PAS-JM 2/8/85*//*begin*/
/*	Don't check for editor type.  Lots of users have their own names
 *	for editors.  Many might accept two file names.
 *	Therefore use whatever editor the user has in ED (unless it's
 *	a null value).  Use option "original_edit" to decide whether to
 *	pass both file names to the editor.
 *						- PAS
 */


/* external variables */

extern char	*getenv() ;


/* local static variables */

static char	*editor ;	/* pointer for name of editor	PAS	*/


editit()
{

/* Check for null	value in ED - PAS */

	if (((editor = getenv("ED")) != NULL) && (*editor != '\0'))
	    strcpy(syscom,editor) ;

	else if (((editor = getenv("EDITOR")) != NULL) && (*editor != '\0'))
	    strcpy(syscom,editor) ;

	else 
	    strcpy(syscom, "ed") ;

	printf("editing message ...\n") ;

	strcat (syscom," ") ;

	sprintf(syscom+strlen(syscom), "%s %s",
	    tempfile, (orig_edit && isoriginal) ? origfile:"") ;
/*PAS-JM 2/8/85*//*end*/

	system(syscom) ;

/* scan message for changes */

	getfield(tempfile,To,recipient) ;

	getfield(tempfile,Cc,copyto) ;

	getfield(tempfile,Bcc,bcopyto) ;

	getfield(tempfile,From,syscom) ;

	getfield(tempfile,Subject,subject) ;

	tonames = getnames(recipient) ;

	ccnames = getnames(copyto) ;

	bccnames = getnames(bcopyto) ;

	isedit = 0 ;
	if (strcmp(from,syscom) != 0) {

	    if (*sentby == '\0') strcpy( sentby, from) ;

	    strcpy( from, syscom ) ;

	}

	*realto = '\0' ;
/* re-read translation tables if necessary */

	if ( table_has_changed()) regettable() ;

}
/* end subroutine */


