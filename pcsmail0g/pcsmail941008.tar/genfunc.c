static char sccsid[] = "@(#)genfunc.c	PCS 3.0";

/************************************************************************
 *									*
 * The information contained herein is for the use of AT&T Information	*
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	*
 *									*
 *	(c) 1984 AT&T Information Systems				*
 *									*
 * Authors of the contents of this file:				*
 *									*
 *		J.Mukerji						*
 *									*
 ************************************************************************/



#include	<stdio.h>

#include	<string.h>

#include	"config.h"

#include	"smail.h"



extern struct fnentry functab[];


int genfunc( fninfo, state )
struct	table	*fninfo;
int	state;
{
    struct	fnentry	*current;
    char	*cur_prefix;

    if ((state < 0) || (state > 2)) {

	printf("genfunc: invalid state %d\n", state);

	return(0);
    }
    current = &functab[0];
    cur_prefix = current->prefix;
    while ( *cur_prefix != '\0' ) {

	if ( strncmp( fninfo->last, cur_prefix, strlen(cur_prefix)) != 0 ) {

		current++;
		cur_prefix = current->prefix;
		continue;
	}
	return ((*current->funct[state])(fninfo));
    }
    printf("sendmail: unknown mailbox %s\n", fninfo->last);

    return(0);
}


