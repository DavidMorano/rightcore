static char sccsid[] = "@(#)doinfo.c	PCS 3.0";

/************************************************************************
 *									*
 * The information contained herein is for the use of AT&T Information	*
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	*
 *									*
 *	(c) 1984 AT&T Information Systems				*
 *									*
 * Authors of the contents of this file:				*
 *									*
 *		J.Mukerji						*
 *									*

 * doinfo() collects a bunch of names from the command line and runs
 * checkname(name,mode) on each of them. mode = 0 if '-' option is specified
 * mode =2 otherwise. The value returned in exit is 0 if the name is found
 * 1 otherwise.


***************************************************************************/



#include	<stdio.h>

#include	"config.h"

#include	"smail.h"



/* external variables */

extern struct global	g ;



int doinfo(argc, argv)
int  argc;
char **argv;
{
	int i, mode;


/* first get the names of files that contain name translation */

	mode = 2 ;
	if (argc < 2) {

	infousage() ;

	return OK ;
	}

	if (namelist[0] == '\0')
	    fprintf(stdout,
	        "warning: translation table not defined.\n");

/* now get the contents of the translation tables */

	gettable(g.nodename) ;

	argv++;		/* skip the command name */
	if ( **argv == '-' ) {
	    mode = 0; 
	    argv++;
	}

	if ( **argv == '+')

	    if (! strncmp( "+verbose", *argv, strlen(*argv))) {

	        verbose = 1; 
	        argv++;

	    } else {

		infousage() ;

		return OK ;
	    }

	while (*argv != NULL) {

#ifdef	DEBUG_DOINFO
fprintf(stderr,"before\n") ; fflush(stderr) ;
#endif

	    i = checkname(*argv++, mode);

#ifdef	DEBUG_DOINFO
fprintf(stderr,"after\n") ; fflush(stderr) ;
#endif

	}

	if (i) i = 0 ;

	else i = 1;

	return i ;
}


infousage()
{
	printf(
	    "usage: %s [-] [+verbose] name1  .....  namen\n", 
	g.progname) ;

}


