static char sccsid[] = "@(#)cookname.c	PCS 3.1";

/************************************************************************
 *									
 * The information contained herein is for the use of AT&T Information	
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	
 *									
 *	(c) 1984 AT&T Information Systems				
 *									
 * Authors of the contents of this file:				
 *									
 *		J.Mukerji						
 *		A.M.Toto						
 *									
*									
*									
*	FUNCTIONAL DESCRIPTION:						
*	'Cookname' marks all entries in the table for mailing.		
*	It also sorts the recipients into destination mailbags.	(AMT)	
*									
*	PARAMETERS:							
*									
*	RETURNED VALUE:							
*									
*	SUBROUTINES CALLED:						
*									

************************************************************************/



#include	<stdio.h>

#include	<string.h>

#include	<pwd.h>

#include	"config.h"

#include	"smail.h"



/* external subroutines */

extern struct passwd	*getpwuid() ;

extern char		*parsename() ;


/* external variables */

extern struct global	g ;



/* convert real names into user names */

int cookname(realname,flag)
char *realname;
int flag;
{
	FILE *fopen(), *fp;

	struct table *nmalloc();
	struct table *tname, *aname;
	struct table *mname;

	int	i, k ;		/* Add k for aliases PAS-JM 2/14/85 */
	int	f_first ;

	char	group[BUFSIZE] ;
	char	s[BUFSIZE] ;
	char	*cp, *cp2 ;


	realname = parsename(realname);

	if (*curaddr != '\0') {

/* address is given with the name so use it */
/* but first enter the name in the translation table */

	    if ((tname = nmalloc()) == NULL) {

	        fprintf(stderr,"translation table too large\n");

	        rmtemp(1);
	    }

	    strcpy(tname->last,selectname);

	    strcpy(tname->user, curaddr);

	    put_in_mailbag( tname, flag );

	    return BAD ;
	}

/* check for groupname */

	if (*realname == STANLIST || *realname == ALTLIST) {

	    realname++;

/* open mailing list */

	    if (genname(realname,group,sizeof(group)) != 1) return OK ;

	    if ((fp = fopen(group,"r")) == NULL) return OK ;

	    f_first = FALSE ;
	    while (fgetline(fp,s,BUFSIZE) > 0)  {

/* skip over leading white space */

		cp = s ;
		while ((*cp == ' ') || (*cp == '\t')) cp += 1 ;

/* ignore comment lines */

		if (*cp == '#') continue ;

/* read up to some more white space or the end */

		if ((cp2 = strpbrk(cp," \t\\\n")) != ((char *) 0))
			*cp2 = '\0' ;

/* is it a UPAS first line ? */

		if (! f_first) {

		    f_first = TRUE ;
		    if (strcmp(cp,realname) == 0) continue ;

		}

	        if (*cp == '\0') continue ;

	        cookname(cp,flag + 10);

	    }

	    fclose(fp) ;

/* else check for -me */

	} else if (strcmp(realname,"-me") == 0) {

/*PAS-JM 2/8/85*/

	    if (myname < 0) {

/* assume it is a login name */
	        if ((tname = nmalloc()) == NULL) {

	            fprintf(stderr,"translation table too large\n") ;

	            rmtemp(1) ;
	        }
	        strcpy(tname->last,getpwuid( getuid() )->pw_name) ;

	        strcpy(tname->user,getpwuid( getuid() )->pw_name) ;

	        put_in_mailbag( tname, flag ) ;

	    } else {

	        mname = name[myname] ;
	        put_in_mailbag( mname, flag ) ;

	    }

	} else { /* translate name if can */

	    i = 0 ;

/* there used to be a while loop here to take care of ambiguities */
/* but now that checkname guarantees that no ambiguous name get   */
/* through to here we can safely dispose of the loop and save    */
/* time and memory!						  */

	    if (findname(realname,&i,TT_ALL) >= 0) {

	        aname = name[i] ;

/* Make sure that aliases are handled right PAS-JM 2/14/85 */

	        if (aname->user[0] == ALIAS) k = 1 ;

	        else k = 0 ;

	        put_in_mailbag( aname, flag ) ;

	    } else if (flag < 10 || strpbrk(realname,"@!/:%") != NULL ) {

/* if no match, add to end of table ; assume it is a login name */

	        if ((tname = nmalloc()) == NULL) {

	            fprintf(stderr,
	                "translation table too large\n") ;

	            rmtemp(1) ;

	        }
	        strcpy(tname->last,realname) ;

/* take care of the !login form */

	        if (*realname == '!') {

	            realname++ ;
	        }

/* Now try to find a path to the site of the user */
/* and save that as the address of the user	  */

	        strcpy(tname->user,realname) ;

	        put_in_mailbag(tname, flag) ;

	    }
	}

	return OK ;
}
/* end subroutine (cookname) */


/* 
 * put_in_mailbag( aname, flag ) sorts the addressees into mailbags
 * based on the immediate neighbor to which they are to be sent. This 
 * uses the bld_link function written by A.M.T.
*/

put_in_mailbag( aname, flag )
struct table *aname ;
int flag ;
{
	char hname[SYSNAME] ;	/* local copy of the immediate neighbour */
	char *c, *d ;


/* message destined for special mailbox like bb or netnews */

	if (flag == SPECIAL) {

	    aname->mail = 1 ;
	    strcpy( hname, "SPECIAL" ) ;

	} else {	/* normal mail message */

	    if (aname->mail == 0 || flag < aname->mail)
	        aname->mail = flag ;

/* now figure out who the immediate neighbour is     */
/* first remove leading alias marks and bangs if any */

	    d = aname->user ;
	    if ((*d == ALIAS) || (*d == '!'))
	        strcpy( aname->user, &aname->user[1]) ;

/* following code adapted from an original written   */
/* by A.M.T in deliverem.c			     */

	    c = strchr( d, '!' ) ;

/* PAS-JM 2/13/85 */
/* we are dealing with a local site */

	    if (c == NULL || *c == '\0') {

	        strcpy(hname,"LOC") ;

	    } else {	/* remote mail */

	        *c = '\0' ;
	        strcpy(hname,d) ;

	        if (!strcmp(hname,g.nodename))
	            strcpy(hname,"LOC") ;

	        *c = '!' ;
	    }
	}

	bld_link(aname, hname) ;

#ifdef	COMMENT
	printf("putinmbag: last %s user %s mail %d, syslink %o\n",
	    aname->last, aname->user, aname->mail, aname->syslink);
#endif

}
/* end subroutine */


