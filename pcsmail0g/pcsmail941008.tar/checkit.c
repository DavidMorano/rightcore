static char sccsid[] = "@(#)checkit.c	PCS 3.0";

/************************************************************************
 *									*
 * The information contained herein is for the use of AT&T Information	*
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	*
 *									*
 *	(c) 1984 AT&T Information Systems				*
 *									*
 * Authors of the contents of this file:				*
 *									*
 *		J.Mukerji						*
 *									*
*
 * checkit() does the footwork for the "check" command.


*************************************************************************/


#include <string.h>
#include <stdio.h>

#include "config.h"
#include	"smail.h"
#include "header.h"


checkit()
{


	getfield(tempfile,To,recipient);
	tonames = getnames(recipient);
	getfield(tempfile,Cc,copyto);
	ccnames = getnames(copyto);
	if (ccnames == 0) {

		getfield(tempfile,"COPY TO:",copyto);
		ccnames = getnames(copyto);
	}
	getfield(tempfile,Bcc,bcopyto);
	bccnames = getnames(bcopyto);
	/* check TO:, BCC:, CC: list */
	checkreclist(1);
} 
/* end wubroutine */


