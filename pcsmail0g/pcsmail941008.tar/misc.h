/* last modified %G% version %I% */


#ifndef		BAD
#define		TRUE		1
#define		FALSE		0
#define		YES		1
#define		NO		0
#define		OK		0
#define		BAD		-1
#endif


#ifndef		NULL
#define		NULL		((char *) 0)
#endif


#ifndef	MIN
#define	MIN(a,b)	(((a) < (b)) ? (a) : (b))
#endif

#ifndef	MAX
#define	MAX(a,b)	(((a) > (b)) ? (a) : (b))
#endif



