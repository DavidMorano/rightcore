static char sccsid[] = "@(#)getnames.c	PCS 3.0" ;

/************************************************************************
 *									
 * The information contained herein is for the use of AT&T Information	
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	
 *									
 *	(c) 1984 AT&T Information Systems				
 *									
 * Authors of the contents of this file:				
 *									
 *		J.Mukerji						
 *									

*									
*	FUNCTIONAL DESCRIPTION:						
*	'Getnames' converts a string into an array of names.		
*									
*	PARAMETERS:							
*	recipient	string of recipients				
*									
*	RETURNED VALUE:							
*	number of recipients						
*									
*	SUBROUTINES CALLED:						
*	char *parsename(string)						
*									
*	DESCRIPTION:							
*	getnames is given a string of names separated by commas or	
*	spaces. spaces are acceptable as separators provided the string 
*	does not contain any embedded spaces in names. Strings contain	
*	embedded spaces in names only if they also contain a 		
*	corresponding address surrounded by <>.				
*	It breaks that string into individual names and passes each	
*	of them to parsename. Parsename deals with the internal 	
*	structure of the name. It eventually puts the name together in	
* 	a canonical form and returns it as the function value.
*									
*	NAME STRUCTURE:							
*									
*	<recipient-list> ::= <recipient>|<recipient>','<recipient-list>	
*	<recipient> ::= <name>|<name>' ''<'<address>'>'|<address>	
*	<name> ::= <string of characters not conataining ','>		
*	<address> ::= <string of characters not containing ','>		
*									

************************************************************************/



#include	<stdio.h>
#include	<string.h>

#include	"config.h"
#include	"smail.h"



#define openstring(ptr, str)	ptr = str	/* char *ptr, *str */

#define addstring(ptr,strn)	for( ; *ptr++ = *strn++; ); ptr--

#define closestring(ptr)	*ptr = '\0'



/* external variables */

extern struct global		g ;


/* forward references */

char	*parsename() ;



int getnames(recipient)
char *recipient ;
{
	int i ;

	char *c, *d, *e ;
	char s[2*BUFSIZE] ;
	char *separator ;


	if (recipient == NULL || *recipient == '\0') /* PAS-JM 2/12/85 */
	    return 0 ;

	i = 0 ;

#ifdef	COMMENT
	if (strchr(recipient, '<') != NULL) separator = "," ;

	else separator = ", " ;
#else
	separator = "," ;
#endif

	openstring( c, s ) ;

	d = parsename(strtok(recipient, separator)) ;

/* PAS-JM 2/12/85 */

	if (d != NULL) addstring( c, d ) ;

	i = 1 ;
	d = strtok( 0, separator ) ;

	while (d != NULL) {

	    e = ", " ;
	    addstring( c, e ) ;

	    d = parsename(d) ;

	    addstring( c, d ) ;

	    i++ ;
	    d = strtok( 0, separator ) ;

	}
	closestring(c) ;

	if (strlen(s) > BUFSIZE) {

	    printf("%s: too many recipients, list truncated\n",
		g.progname) ;

	    s[BUFSIZE-1] = '\0' ;
	    *strrchr(s, ',') = '\0' ;
	}
	strncpy( recipient, s, BUFSIZE-1 ) ;

	return i ;
}
/* end subroutein (getnames) */


/************************************************************************

  The subroutine 'parsename' does the following :

  - strip any blank prefix from the string				
  - strip any blank postfix from the string				
  - copy the address into global string curaddr				
  - copy the name into global variable selectname			
  - return the stripped string						


************************************************************************/

char *parsename( recipient )
char *recipient ;
{
	char *name, *addr, *temp ;


	name = recipient ;

	*selectname = *curaddr = '\0' ;

/* Strip leading blanks */ /* PAS-JM 2/12/85 */

	while ((name != NULL) && *name && ((*name == ' ') || (*name == '\t')))  
	    name++ ;

/* Strip trailing blanks */

	addr = name ;
	while( *addr ) addr++ ;

	addr-- ;
	while( *addr == ' ' ) addr-- ;

	addr++ ;
	*addr = '\0' ;
	if ((addr = strchr(name, '<')) != NULL) {

	    temp = addr ;
	    strncpy( curaddr, ++addr, SYSLEN ) ;

	    if ((addr = strchr( curaddr, '>' )) == NULL)
	        *curaddr = '\0' ;

	    else
	        *addr = '\0' ;

	    addr = temp ;
	    addr-- ;
	    while( *addr-- == ' ' ) ;

	    addr = addr + 2 ;
	    *addr = '\0' ;
	    strncpy( selectname, name, LENNAME) ;

	    *addr = ' ' ;
	    *temp = '<' ;

	} else strncpy( selectname, name, LENNAME ) ;

	return name ;
}
/* end subroutine (parsename) */



