static char sccsid[] = "@(#)getfield.c	PCS 3.0" ;

/************************************************************************
 *									*
 * The information contained herein is for the use of AT&T Information	*
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	*
 *									*
 *	(c) 1984 AT&T Information Systems				*
 *									*
 * Authors of the contents of this file:				*
 *									*
 *		T.S.Kennedy						*
 *		J.Mukerji						*
 *									*
 


*									*
*				getfield				*
*									*

*									*
*	FUNCTIONAL DESCRIPTION:						*
*	'Getfield' reads a file for a field descriptor and returns	*
*	the data contained in it.					*
*									*
*	PARAMETERS:							*
*	file		filename					*
*	field		field name (eg, 'FROM')				*
*	data		data in field					*
*			must be of size BUFSIZE				*
*									*
*	RETURNED VALUE:							*
*									*
*	SUBROUTINES CALLED:						*

*									*
************************************************************************/



#include	<stdio.h>

#include	"char.h"

#include	"config.h"
#include	"smail.h"



int getfield(file,field,data,buflen)
char file[] ;
char field[] ;
char *data ;
int	buflen ;
{
	FILE *fp ;

	int  len, dlen ;

	char line[BUFSIZE] ;
	char *c, *d ;


/* open file for reading */

	if ((fp = fopen(file,"r")) == NULL) return 0 ;

	*data = '\0' ;
	dlen = 0 ;

/* read file */

	while (fgetline(fp,line, BUFSIZE) > 0) {

	    c = line ;
	    d = field ;

/* check for field */

	    if (*c++ != *d++) continue ;

	    while ( *c != '\0') {

/* match on field */

	        if (*d == '\0') {

/* remove leading white */

	            while (ISWHITE(*c)) c += 1 ;

	            len = strlen(line) ;

/* remove newline */
	            line[ len - 1 ] = '\0' ;

	            if ((dlen += len) < BUFSIZE) {

	                strcat(data,c) ;

	                if (!strncmp("CC",field,2)
	                    || !strncmp("BCC",field,3)) {

	                    strcat(data, " ") ;

	                    goto look_for_more ;
	                }

	            } else if ( ex_mode == ORIG )
	                printf(
"warning - too many names in %s field, list truncated\n",
field) ;

	            fclose(fp) ;

	            return 1 ;
	        }

	        if ((*c++ | 040) != (*d++ | 040)) break ;
	    }

look_for_more:
	    continue ;

	}

	fclose(fp) ;

	return 0 ;
}



