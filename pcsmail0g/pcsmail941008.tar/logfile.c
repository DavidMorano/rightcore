/* logfile */


/***********************************************************************

	Module to operate on the logfile.


************************************************************************/



#define	DEBUG	0



#include	<sys/types.h>
#include	<sys/stat.h>
#include	<fcntl.h>
#include	<varargs.h>

#if	DEBUG
#include	<stdio.h>
#include	"config.h"
#include	"smail.h"
#endif

#include	"misc.h"




#define	OFLAGS	(O_WRONLY | O_APPEND | O_CREAT)
#define	BUFLEN	100



/* external subroutines */

extern int	open(), write() ;

extern int	format(), sprintf() ;


/* global data */

#if	DEBUG
extern struct global	g ;
#endif


/* local global data */

static int	lfd = -1, pl ;
static char	buf[BUFLEN + 1] ;




int logopen(lf,id)
char	*lf ;
int	id ;
{


	if ((lfd = open(lf,OFLAGS,0666)) < 0) return BAD ;

	chmod(lf,0666) ;

	pl = sprintf(buf,"%d\t: ",id) ;

	return lfd ;
}
/* end subroutine */


int logprintf(va_alist)
va_dcl
{
	va_list		ap ;

	int		l, l2 ;

#if	DEBUG
	char		buf2[100] ;
#endif


	if (lfd < 0) return BAD ;

	va_start(ap) ;

	l = format(buf + pl,(BUFLEN - pl),ap) ;

#if	DEBUG
	l2 = sprintf(buf2,"opid=%d cpid=%d length=%d buflen-pl=%d\n",
		g.pid,getpid(),l,BUFLEN - pl) ;

	write(2,buf2,l2) ;
#endif

	if (l >= (BUFLEN - pl - 1)) buf[pl + l++] = '\n' ;

	l = write(lfd,buf,pl + l) ;

	va_end(ap) ;

	return l ;
}
/* end subroutine (logprintf) */


