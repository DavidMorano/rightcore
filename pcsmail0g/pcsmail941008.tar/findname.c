static char sccsid[] = "@(#)findname.c	PCS 3.0" ;

/************************************************************************
 *									
 * The information contained herein is for the use of AT&T Information	
 * Systems Laboratories and is not for publications.  (See GEI 13.9-3)	
 *									
 *	(c) 1984 AT&T Information Systems				
 *									
 * Authors of the contents of this file:				
 *									
 *		T.S.Kennedy						
 *		J.Mukerji						
 *									
*									
*	FUNCTIONAL DESCRIPTION:						
*	'Findname' returns the entry number for the next name which	
*	matches the realname.						
*									
*	PARAMETERS:							
*	realname	real name of user				
*	start		place to start looking in table			
*									
*	RETURNED VALUE:							
*	[n]	entry number in table (if match)			
*	-1	no match						
*									
*	SUBROUTINES CALLED:						
*									


*	Note: ":" added to strpbrk						


************************************************************************/



#define		DEBUG	0



#include	<string.h>
#include	<stdio.h>

#include	"config.h"
#include	"smail.h"



int findname(realname,start,type)
char	*realname ;
int	*start ;
int	type ;
{
	struct table	*aname ;

	int		i, j ;


/* if realname contains a ! then searching for it */
/* in the name database is quite futile, so return a -1  */

	if (strchr(++realname, '!') != NULL) return -1 ;

	realname-- ;

/* translate name if can */

	while (*start < tablelen) {

	    aname = name[*start] ;
#if	DEBUG
	if (strcmp(aname->last,"w.m.pitio") == 0) {

	eprintf("search name \"%s\" st=%d tt=%d\n",
		realname,type,aname->type) ;

	}
#endif

	    if ((type == aname->type) || (type == TT_ALL)) {

	        if (*realname == '!') {	/* check for login name */

	            if (strcmp(realname+1,aname->user) == 0)
	                return *start ;

	        } else if (cmpnames(realname,aname->last)) {

	            if (*(aname->user) == ALIAS) {

	                if (strpbrk(aname->user,"!@:%/") != NULL) {

/* a mail address path has been found */
	                    return *start ;

	                }
	                i = 0 ;
	                j = findname( (aname->user) + 1,&i,TT_ALL) ;

	                if (j < 0) return -1 ;

	                *start = i ;
	                return *start ;
	            }

#ifdef	COMMENT
	            if (strchr( aname->user, NONMAIL ) != NULL)
	                return 0 ;
#endif

	            return *start ;

	        } /* end if */

	    } /* end if */

	    *start += 1 ;

	} /* end while */

	return -1 ;
}
/* end subroutine (findname) */


